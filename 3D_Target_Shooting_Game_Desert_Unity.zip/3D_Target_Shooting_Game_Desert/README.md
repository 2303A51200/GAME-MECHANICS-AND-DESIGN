# 3D Target Shooting Game (Arrow) - Desert Edition

A desert-themed (sand dunes, cacti, red mesas, hot sun) first-person 3D archery game made with Unity (C#, built-in primitives only, no paid assets).

## How to open and run

1. Install **Unity Hub** and a **Unity 6 LTS (6000.0.x)** editor (with Windows Build Support if you want to make an .exe).
2. Extract `3D_Target_Shooting_Game_Unity.zip`.
3. In Unity Hub click **Add > Add project from disk** and choose the `3D_Target_Shooting_Game` folder.
4. If Hub says the editor version is missing, pick any installed Unity 6 (6000.x) editor in the dropdown and open it.
5. Wait for the first import (1-3 minutes). **The project builds itself automatically**: materials, prefabs, the MainMenu and GameScene scenes and the Build Settings are created by `Assets/Editor/ArcheryProjectBuilder.cs`. A "Setup complete" window appears when it is done.
6. The **MainMenu** scene is now open. Press the **Play** button and click **START GAME**.

If the setup window does not appear, or you ever want to rebuild everything, use the menu **Archery > Build Complete Game**.

## Controls

| Input | Action |
|-------|--------|
| Mouse move | Aim |
| Left click | Shoot an arrow |
| Right mouse (hold) | Zoom in |
| R | Restart |
| Esc or P | Pause / resume |

(In the Unity Editor, Esc also releases the mouse cursor - use P to pause if Esc does not respond.)

## Rules

* 10 arrows per round; the round ends when every arrow has landed.
* Yellow centre = 10, red = 8, blue = 6, black = 4, white = 2. Each arrow scores once.
* Arrows drop with distance - aim a little higher at the far targets (zoom helps).
* Score 60 or more to win. Your best score is saved.

## Project layout

* `Assets/Scripts` - GameManager, PlayerController, BowController, ArrowController, TargetController, ScoreManager, UIManager, MenuUI, AudioManager
* `Assets/Editor/ArcheryProjectBuilder.cs` - one-click scene/prefab/material builder (runs automatically on first open)
* `Assets/Scenes`, `Assets/Prefabs`, `Assets/Materials` - filled by the builder (Arrow, Bow, Target prefabs)
* `Assets/Audio` - optional: sounds and music are generated in code. To use your own, assign clips to the AudioManager component in either scene.

## Notes

* Uses the Built-in Render Pipeline and Unity's legacy Input Manager, so nothing extra needs to be installed. UI uses Unity UI (`UnityEngine.UI`).
* To build a Windows .exe: File > Build Profiles (Build Settings) > Windows > Build.
