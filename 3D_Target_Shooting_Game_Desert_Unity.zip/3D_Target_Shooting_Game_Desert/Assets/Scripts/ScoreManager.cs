using UnityEngine;

/// <summary>Keeps track of the score and the saved high score.</summary>
public class ScoreManager : MonoBehaviour
{
    public const string HighScoreKey = "ArcheryHighScore";

    public int Score { get; private set; }
    public int HighScore { get; private set; }

    void Awake()
    {
        HighScore = PlayerPrefs.GetInt(HighScoreKey, 0);
    }

    public void ResetScore()
    {
        Score = 0;
    }

    public void AddScore(int points)
    {
        Score += points;
    }

    /// <summary>Saves the score if it beats the old record. Returns true for a new record.</summary>
    public bool SaveHighScore()
    {
        if (Score > HighScore)
        {
            HighScore = Score;
            PlayerPrefs.SetInt(HighScoreKey, HighScore);
            PlayerPrefs.Save();
            return true;
        }
        return false;
    }
}
