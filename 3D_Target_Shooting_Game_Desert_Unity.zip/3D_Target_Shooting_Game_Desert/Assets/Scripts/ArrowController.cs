using UnityEngine;

/// <summary>
/// Controls one arrow: flies with physics, points along its flight path,
/// sticks into whatever it hits and reports its score exactly once.
/// </summary>
[RequireComponent(typeof(Rigidbody))]
public class ArrowController : MonoBehaviour
{
    public float maxFlightTime = 8f;
    public float embedDepth = 0.18f;

    Rigidbody rb;
    bool resolved;
    Vector3 lastPosition;
    float flightTimer;

    void Awake()
    {
        rb = GetComponent<Rigidbody>();
        rb.freezeRotation = true; // we rotate the arrow ourselves to follow its path
    }

    public void Launch(Vector3 direction, float speed)
    {
        direction.Normalize();
        transform.rotation = Quaternion.LookRotation(direction);
        lastPosition = transform.position;
        rb.AddForce(direction * speed, ForceMode.VelocityChange);
    }

    void FixedUpdate()
    {
        if (resolved) return;

        flightTimer += Time.fixedDeltaTime;
        Vector3 delta = rb.position - lastPosition;
        if (delta.sqrMagnitude > 0.0004f)
        {
            rb.rotation = Quaternion.LookRotation(delta);
            lastPosition = rb.position;
        }

        // Safety net: arrow flew away forever.
        if (flightTimer > maxFlightTime || rb.position.y < -10f)
        {
            resolved = true;
            if (GameManager.Instance != null) GameManager.Instance.ArrowResolved(0, null);
            Destroy(gameObject);
        }
    }

    void OnCollisionEnter(Collision collision)
    {
        if (resolved) return;
        resolved = true;

        TargetController target = collision.collider.GetComponentInParent<TargetController>();
        int points = 0;
        if (target != null)
        {
            points = target.GetScore(collision.GetContact(0).point);
        }

        Stick(target);

        if (AudioManager.Instance != null) AudioManager.Instance.PlayImpact();
        if (GameManager.Instance != null) GameManager.Instance.ArrowResolved(points, target);
    }

    void Stick(TargetController target)
    {
        rb.isKinematic = true;
        Collider col = GetComponent<Collider>();
        if (col != null) col.enabled = false;

        transform.position += transform.forward * embedDepth; // push the tip into the surface
        if (target != null) transform.SetParent(target.transform, true);
    }
}
